def satellite_forces_simple(altitude, velocity, C_d):
    # Extract coordinates

    # Atmospheric density calculation
    rho = rho_0 * np.exp(-altitude / H)

    velocity = np.array(velocity)
    # Drag force calculation
    Fd = 0.5 * rho * velocity**2 * C_d * A

    return Fd