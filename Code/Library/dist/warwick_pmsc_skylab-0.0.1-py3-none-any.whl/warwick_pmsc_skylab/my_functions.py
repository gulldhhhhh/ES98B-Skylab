def test():
    print("test")